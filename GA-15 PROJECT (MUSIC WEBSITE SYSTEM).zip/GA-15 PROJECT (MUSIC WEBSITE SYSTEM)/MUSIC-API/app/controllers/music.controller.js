const Music = require("../models/music.model.js");

// Create and Save a new Customer
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Customer
  const music = new Music({
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    message: req.body.message
  });

  // Save music_site in the database
  Music.create(music, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Music."
      });
    else res.send(data);
  });
};

// Retrieve all music_site from the database.
exports.findAll = (req, res) => {
  Music.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving music_site."
      });
    else res.send(data);
  });
};

// Find a single member with a musicId
exports.findOne = (req, res) => {
  Music.findById(req.params.musicId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found name with id ${req.params.musicId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving name with id " + req.params.musicId
        });
      }
    } else res.send(data);
  });
};

// Update a member identified by the musicId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  Customer.updateById(
    req.params.musicId,
    new Music(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found member with id ${req.params.musicId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating member with id " + req.params.musicId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a Customer with the specified musicId in the request
exports.delete = (req, res) => {
  Music.remove(req.params.musicId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found member with id ${req.params.musicId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete member with id " + req.params.musicId
        });
      }
    } else res.send({ message: `member was deleted successfully!` });
  });
};

// Delete all Customers from the database.
exports.deleteAll = (req, res) => {
  Music.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all members."
      });
    else res.send({ message: `All members were deleted successfully!` });
  });
};