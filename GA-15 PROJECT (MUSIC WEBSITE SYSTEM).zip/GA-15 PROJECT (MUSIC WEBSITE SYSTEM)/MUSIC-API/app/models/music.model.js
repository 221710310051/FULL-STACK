const sql=require('./db.js');
const Music=function(music){
    this.name=music.name;
    this.email=music.email;
    this.phone=music.phone;
    this.message=music.message;

};
Music.create =(newMusic,result)=> {
    sql.query('Insert into music_site set ?',newMusic,(err,res) =>{
       if(err){
           console.log(err);
           result(err,null);
           return;
       }
       console.log("created member:",{id:res.insertedId,...newMusic});
       return(null ,{id:res.insertedId,...newMusic});
    })
};
Music.findById=(musicId,result) => {
    sql.query(`select * from music_site where Id=${musicId}`,(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        if(res.length){
            console.log('found member:',res[0]);
            result(null,res[0]);
            return;
        }
        result({kind:'not_found'},null);
    })
};
Music.getAll=result =>{
    sql.query('select * from music_site',(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        console.log('Members:',res);
        result(null,res);
    })
};
Music.updateById=(id,music,result)=>{
    sql.query('Update music_site set name=?,email=?,phone=?,message=? where id=?',
    [music.name,music.email,music.phone,music.message,id],(err,res)=>{
            if(err){
                console.log(err);
                result(err,null);
                return;
            }
            if(result.affectedRows==0){
                result({kind:'Not_found'},null);
                return;
            }
            console.log('updated member:',{id:id,...music});
            result(null,{id:id,...music});
    });
};
Music.remove=(id,result)=>{
    sql.query('delete from music_site where id=?',id,(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        if(result.affectedRows==0){
            result({kind:'Not_found'},null);
            return;
        }
        console.log('deleted member with id:',id);
        result(null,res);


    });
};
Music.removeAll=result=>{
    sql.query('delete from music_site',(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        console.log('delete ${res.affectedRows} music_site');
        result(null,res);
    });
};
module.exports=Music;