const sql=require('./db.js');
const Login=function(login){
    this.username=login.username;
    this.password=login.password;
};
Login.create =(newLogin,result)=> {
    sql.query('Insert into login_music set ?',newLogin,(err,res) =>{
       if(err){
           console.log(err);
           result(err,null);
           return;
       }
       console.log("created member:",{id:res.insertedId,...newLogin});
       return(null ,{id:res.insertedId,...newLogin});
    })
};
Login.findById=(musicId,result) => {
    sql.query(`select * from login_music where Id=${loginId}`,(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        if(res.length){
            console.log('found member:',res[0]);
            result(null,res[0]);
            return;
        }
        result({kind:'not_found'},null);
    })
};
Login.getAll=result =>{
    sql.query('select * from login_music',(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        console.log('Members:',res);
        result(null,res);
    })
};
Login.updateById=(id,login,result)=>{
    sql.query('Update login_music set username=?,password=? where id=?',
    [login_music.username,login_music.password],(err,res)=>{
            if(err){
                console.log(err);
                result(err,null);
                return;
            }
            if(result.affectedRows==0){
                result({kind:'Not_found'},null);
                return;
            }
            console.log('updated member:',{id:id,...login});
            result(null,{id:id,...login});
    });
};
Login.remove=(id,result)=>{
    sql.query('delete from login_music where id=?',id,(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        if(result.affectedRows==0){
            result({kind:'Not_found'},null);
            return;
        }
        console.log('deleted member with id:',id);
        result(null,res);


    });
};
Login.removeAll=result=>{
    sql.query('delete from login_music',(err,res)=>{
        if(err){
            console.log(err);
            result(err,null);
            return;
        }
        console.log('delete ${res.affectedRows} login_music');
        result(null,res);
    });
};
module.exports=Login;