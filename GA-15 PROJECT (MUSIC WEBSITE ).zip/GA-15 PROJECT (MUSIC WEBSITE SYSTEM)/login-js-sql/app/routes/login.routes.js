module.exports=app=>{
    const login_music=require('../controllers/login.controller.js');
    app.post("/login_music",login_music.create);
    app.get('/login_music',login_music.findAll);
    app.get('/login_music/:musicId',login_music.findOne);
    app.put('/login_music/:musicId',login_music.update);
    app.delete('/login_music/:musicId',login_music.delete);
    app.delete('/login_music',login_music.deleteAll);
};