const Login = require("../models/login.model.js");

// Create and Save a new Customer
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a login
  const login = new Login({
    username: req.body.username,
    password: req.body.password
  });

  // Save login in the database
  Login.create(login, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the login."
      });
    else res.send(data);
  });
};

// Retrieve all login from the database.
exports.findAll = (req, res) => {
  Login.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving login."
      });
    else res.send(data);
  });
};

// Find a single member with a musicId
exports.findOne = (req, res) => {
  Login.findById(req.params.loginId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found name with id ${req.params.loginId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving name with id " + req.params.loginId
        });
      }
    } else res.send(data);
  });
};

// Update a member identified by the musicId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  Login.updateById(
    req.params.loginId,
    new Login(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found member with id ${req.params.loginId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating member with id " + req.params.loginId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a member with the specified loginId in the request
exports.delete = (req, res) => {
  Login.remove(req.params.loginId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found member with id ${req.params.loginId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete member with id " + req.params.loginId
        });
      }
    } else res.send({ message: `member was deleted successfully!` });
  });
};

// Delete all members from the database.
exports.deleteAll = (req, res) => {
  Login.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all members."
      });
    else res.send({ message: `All members were deleted successfully!` });
  });
};