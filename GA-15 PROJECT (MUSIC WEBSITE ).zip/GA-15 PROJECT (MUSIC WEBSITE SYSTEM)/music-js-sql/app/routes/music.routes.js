module.exports=app=>{
    const music_site=require('../controllers/music.controller.js');
    app.post("/music_site",music_site.create);
    app.get('/music_site',music_site.findAll);
    app.get('/music_site/:musicId',music_site.findOne);
    app.put('/music_site/:musicId',music_site.update);
    app.delete('/music_site/:musicId',music_site.delete);
    app.delete('/music_site',music_site.deleteAll);
};