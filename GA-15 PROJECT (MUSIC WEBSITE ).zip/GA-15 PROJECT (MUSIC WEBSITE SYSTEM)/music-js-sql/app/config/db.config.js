module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "saikiran51$",
    DB:"testdb"

};

